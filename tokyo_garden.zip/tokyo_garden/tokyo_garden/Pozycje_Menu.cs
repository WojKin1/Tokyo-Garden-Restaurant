﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Pozycje_Menu
    {
        public int id { get; set; }
        public decimal cena { get; set; }
        public string nazwa_pozycji { get; set; }
        public string opis { get; set; }
        public string skladniki { get; set; }
        public byte[] image_data { get; set; }
        public virtual ICollection<Alergeny> alergeny { get; set; }
        public virtual Kategorie_Menu kategoria_menu { get; set; }
    }
}
