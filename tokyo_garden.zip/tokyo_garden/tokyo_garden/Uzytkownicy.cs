﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Uzytkownicy
    {
        public int id { get; set; }
        public string nazwa_uzytkownika { get; set; }
        public string haslo { get; set; }
        public string telefon { get; set; }
        public string typ_uzytkownika { get; set; }
        public virtual ICollection<Zamowienia> zamowienia { get; set; }
    }

}
