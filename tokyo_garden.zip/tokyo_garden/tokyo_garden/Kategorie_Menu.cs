﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Kategorie_Menu
    {
        public int id { get; set; }
        public string nazwa_kategorii { get; set; }
        public virtual ICollection<Pozycje_Menu> pozycje_menu { get; set; }
    }
}
