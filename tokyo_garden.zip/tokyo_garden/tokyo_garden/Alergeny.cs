﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Alergeny
    {
        public int id { get; set; }
        public string nazwa_alergenu { get; set; }
        public string opis_alergenu { get; set; }
        public virtual ICollection<Pozycje_Menu> pozycje_menu { get; set; }
    }
}
