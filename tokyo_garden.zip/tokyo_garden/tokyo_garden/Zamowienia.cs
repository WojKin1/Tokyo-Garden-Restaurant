﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Zamowienia
    {
        public int id { get; set; }
        public DateTime data_zamowienia { get; set; }
        public string dodatkowe_informacje { get; set; }
        public string status_zamowienia { get; set; }
        public decimal laczna_cena { get; set; }
        public string metoda_platnosci { get; set; }
        public string opcje_zamowienia { get; set; }
        public virtual ICollection<Pozycje_Zamowienia> pozycje_zamowienia { get; set; }
        public virtual Uzytkownicy uzytkownik { get; set; }
    }
}
