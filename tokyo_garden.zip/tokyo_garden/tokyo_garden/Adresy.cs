﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Adresy
    {
        public int id { get; set; }
        public string miasto { get; set; }
        public string nr_domu { get; set; }
        public string nr_mieszkania { get; set; }
        public string ulica { get; set; }
    }

}
