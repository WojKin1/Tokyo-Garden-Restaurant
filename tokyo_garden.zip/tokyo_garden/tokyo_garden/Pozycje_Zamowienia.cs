﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tokyo_garden
{
    public class Pozycje_Zamowienia
    {
        public int id { get; set; }
        public decimal cena { get; set; }
        public int ilosc { get; set; }
        public virtual Zamowienia zamowienie { get; set; }
        public virtual Pozycje_Menu pozycja_menu { get; set; }
    }
}
